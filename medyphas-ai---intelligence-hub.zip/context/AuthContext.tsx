import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  login: (role: UserRole) => void;
  logout: () => void;
  apiKey: string;
  setApiKey: (key: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [apiKey, setApiKeyState] = useState<string>('');

  useEffect(() => {
    // Load persisted state
    const storedUser = localStorage.getItem('medyphas_user');
    const storedKey = localStorage.getItem('medyphas_api_key');
    
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    if (storedKey) {
      setApiKeyState(storedKey);
    }
  }, []);

  const login = (role: UserRole) => {
    let newUser: User;
    if (role === 'DOCTOR') {
      newUser = {
        id: 'DOC-001',
        name: 'Dr. Sarah Chen',
        role: 'DOCTOR',
        avatar: 'https://picsum.photos/100/100'
      };
    } else {
      newUser = {
        id: 'PT-8832',
        name: 'John Doe',
        role: 'PATIENT',
        avatar: 'https://picsum.photos/101/101'
      };
    }
    setUser(newUser);
    localStorage.setItem('medyphas_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('medyphas_user');
  };

  const setApiKey = (key: string) => {
    setApiKeyState(key);
    if (key) {
      localStorage.setItem('medyphas_api_key', key);
    } else {
      localStorage.removeItem('medyphas_api_key');
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, apiKey, setApiKey }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};