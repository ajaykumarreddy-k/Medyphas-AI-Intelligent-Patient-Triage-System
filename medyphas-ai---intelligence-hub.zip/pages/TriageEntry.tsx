import React, { useState, useEffect } from 'react';
import { assessPatientRisk } from '../services/geminiService';
import { RiskLevel } from '../types';
import { useAuth } from '../context/AuthContext';
import { Link } from 'react-router-dom';

export const TriageEntry: React.FC = () => {
  const { apiKey } = useAuth();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  
  // BYOK State
  const [hasStudioKey, setHasStudioKey] = useState(false);
  const [checkingStudioKey, setCheckingStudioKey] = useState(true);

  // Form State
  const [age, setAge] = useState<number>(45);
  const [gender, setGender] = useState('Male');
  const [symptoms, setSymptoms] = useState<string[]>(['Chest Pain', 'Shortness of Breath']);
  const [vitals, setVitals] = useState({
    bpSystolic: 165,
    bpDiastolic: 82,
    heartRate: 98,
    temp: 37.1,
    spo2: 99
  });

  useEffect(() => {
    const checkStudioKey = async () => {
      const win = window as any;
      if (win.aistudio) {
        try {
          const hasSelected = await win.aistudio.hasSelectedApiKey();
          setHasStudioKey(hasSelected);
        } catch (e) {
          console.error(e);
        }
      }
      setCheckingStudioKey(false);
    };
    checkStudioKey();
  }, []);

  const handleSelectKey = async () => {
    const win = window as any;
    if (win.aistudio) {
      try {
        await win.aistudio.openSelectKey();
        setHasStudioKey(true);
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleSymptomToggle = (symptom: string) => {
    if (symptoms.includes(symptom)) {
      setSymptoms(symptoms.filter(s => s !== symptom));
    } else {
      setSymptoms([...symptoms, symptom]);
    }
  };

  const handleGenerateDiagnosis = async () => {
    setLoading(true);
    setResult(null);
    const assessment = await assessPatientRisk(age, gender, symptoms, vitals);
    
    // Check if assessment returned a specific error indicating auth failure, though assessPatientRisk masks it.
    // Since we have the blocker, we assume mostly success, but if it fails, result.diagnosis usually contains the error.
    
    setResult(assessment);
    setLoading(false);
  };

  // Blocker Check
  const showBlocker = !checkingStudioKey && !apiKey && !process.env.API_KEY && !hasStudioKey;

  if (showBlocker) {
    return (
      <div className="h-full flex items-center justify-center p-6 animate-in fade-in duration-500">
        <div className="bg-surface-light dark:bg-surface-dark p-10 rounded-clay shadow-clay dark:shadow-clay-dark text-center max-w-md border border-white/50 dark:border-slate-700">
          <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/30 text-amber-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
            <span className="material-symbols-outlined text-4xl">key_off</span>
          </div>
          <h2 className="text-2xl font-bold text-slate-800 dark:text-white mb-2">API Key Required</h2>
          <p className="text-slate-500 dark:text-slate-400 mb-8 leading-relaxed">
            To use the AI Triage Assessment, you must provide a valid Gemini API Key. This prevents usage limits on the development environment.
          </p>
          
          <div className="space-y-4">
            {(window as any).aistudio ? (
                <>
                  <button 
                      onClick={handleSelectKey}
                      className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-xl font-bold shadow-clay-primary hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all"
                  >
                      <span className="material-symbols-outlined">api</span>
                      Connect Google AI Studio
                  </button>
                  <p className="text-[10px] text-slate-400 mt-2">
                    <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noreferrer" className="underline hover:text-primary transition-colors">
                        Learn about billing
                    </a>
                  </p>
                </>
            ) : (
                 <Link 
                    to="/config" 
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-4 bg-primary text-white rounded-xl font-bold shadow-clay-primary hover:-translate-y-0.5 transition-all"
                >
                    <span className="material-symbols-outlined">settings</span>
                    Go to Configuration
                </Link>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row h-full overflow-hidden p-6 gap-6 max-w-[1600px] mx-auto w-full animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Left: Input Form */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2">
        <div className="max-w-4xl mx-auto space-y-8 pb-10">
          
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl font-black text-slate-800 dark:text-slate-100 tracking-tight">Triage Assessment</h1>
              <p className="text-slate-500 dark:text-slate-400 font-medium mt-1">New intake powered by Medyphas AI.</p>
            </div>
            {((window as any).aistudio && hasStudioKey) && (
               <div className="px-3 py-1 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 rounded-lg text-xs font-bold border border-green-200 dark:border-green-800 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500"></span>
                  AI Studio Connected
               </div>
            )}
          </div>

          {/* Stepper */}
          <nav aria-label="Progress">
            <ol className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {step: 1, title: 'Patient Info', sub: 'EHR Upload', active: false, done: true},
                {step: 2, title: 'Vitals', sub: 'Analysis', active: true, done: false},
                {step: 3, title: 'Symptoms', sub: 'Review', active: false, done: false}
              ].map((s) => (
                <li key={s.step}>
                  <div className={`group relative flex items-center p-4 rounded-2xl transition-all ${s.active ? 'bg-[#eef2f6] dark:bg-[#1e293b] shadow-[inset_4px_4px_8px_#d1d9e6,inset_-4px_-4px_8px_#ffffff] dark:shadow-[inset_4px_4px_8px_#0f1521,inset_-4px_-4px_8px_#2d3d55]' : 'hover:bg-white/50 dark:hover:bg-slate-800/50'}`}>
                    <div className={`flex items-center justify-center w-10 h-10 rounded-xl font-bold ${s.active ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/40' : 'bg-slate-200 dark:bg-slate-700 text-slate-500 dark:text-slate-400'}`}>
                      {s.done ? '✓' : s.step}
                    </div>
                    <div className="ml-4 flex flex-col">
                      <span className={`text-xs font-bold uppercase tracking-wider ${s.active ? 'text-primary' : 'text-slate-400'}`}>{s.title}</span>
                      <span className="text-sm font-semibold text-slate-700 dark:text-slate-200">{s.sub}</span>
                    </div>
                  </div>
                </li>
              ))}
            </ol>
          </nav>

          <div className="bg-surface-light dark:bg-surface-dark rounded-clay p-8 border border-white/50 dark:border-slate-700 shadow-clay dark:shadow-clay-dark">
            <div className="space-y-10">
              
              {/* Demographics */}
              <section>
                <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-6 pl-1">
                  <span className="material-symbols-outlined text-lg">person</span> Patient Demographics
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-2">
                    <label className="block text-sm font-bold text-slate-600 dark:text-slate-300 ml-1">Patient Age</label>
                    <div className="relative">
                      <input 
                        type="number" 
                        value={age}
                        onChange={(e) => setAge(parseInt(e.target.value))}
                        className="block w-full text-lg p-4 font-bold text-slate-700 dark:text-slate-200 outline-none bg-[#eef2f6] dark:bg-[#1e293b] rounded-2xl shadow-[inset_5px_5px_10px_#d6dbe4,inset_-5px_-5px_10px_#ffffff] dark:shadow-[inset_4px_4px_8px_#0f1521,inset_-4px_-4px_8px_#2d3d55] border-none focus:ring-2 focus:ring-primary/50" 
                      />
                      <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none">
                        <span className="text-slate-400 font-semibold text-sm">Years</span>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="block text-sm font-bold text-slate-600 dark:text-slate-300 ml-1">Biological Sex</label>
                    <div className="grid grid-cols-3 gap-3 p-2 bg-[#eef2f6] dark:bg-[#1e293b] rounded-2xl shadow-[inset_5px_5px_10px_#d6dbe4,inset_-5px_-5px_10px_#ffffff] dark:shadow-[inset_4px_4px_8px_#0f1521,inset_-4px_-4px_8px_#2d3d55] h-[64px] items-center">
                      {['Male', 'Female', 'Other'].map(opt => (
                        <button 
                          key={opt}
                          type="button"
                          onClick={() => setGender(opt)}
                          className={`h-full rounded-xl text-sm font-bold transition-all ${gender === opt ? 'bg-white dark:bg-slate-600 shadow-md text-primary dark:text-white' : 'text-slate-400 hover:text-slate-600 dark:hover:text-white'}`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              {/* Vitals */}
              <section>
                <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-6 pl-1">
                  <span className="material-symbols-outlined text-lg">ecg_heart</span> Vitals Monitor
                </h3>
                <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-5">
                  {[
                    { label: 'BP Systolic', key: 'bpSystolic', unit: 'mmHg', critical: vitals.bpSystolic > 160 },
                    { label: 'BP Diastolic', key: 'bpDiastolic', unit: 'mmHg', critical: false },
                    { label: 'Heart Rate', key: 'heartRate', unit: 'bpm', critical: vitals.heartRate > 100 },
                    { label: 'Temp', key: 'temp', unit: '°C', critical: false },
                    { label: 'SpO2', key: 'spo2', unit: '%', critical: vitals.spo2 < 95 },
                  ].map((vital: any) => (
                    <div key={vital.key} className={`relative group rounded-2xl p-5 transition-all bg-[#eef2f6] dark:bg-[#1e293b] shadow-[inset_5px_5px_10px_#d6dbe4,inset_-5px_-5px_10px_#ffffff] dark:shadow-[inset_4px_4px_8px_#0f1521,inset_-4px_-4px_8px_#2d3d55] ${vital.critical ? 'shadow-[inset_4px_4px_8px_rgba(239,68,68,0.2),inset_-4px_-4px_8px_rgba(255,255,255,0.1),0_0_15px_rgba(239,68,68,0.4)] border border-danger/30' : ''}`}>
                      <div className="flex justify-between items-start mb-3">
                        <label className={`text-xs font-bold uppercase tracking-wide ${vital.critical ? 'text-danger' : 'text-slate-400'}`}>{vital.label}</label>
                        {vital.critical && <span className="h-2 w-2 rounded-full bg-danger animate-pulse shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span>}
                      </div>
                      <div className="flex items-baseline gap-1">
                        <input 
                          type="number"
                          value={(vitals as any)[vital.key]}
                          onChange={(e) => setVitals({...vitals, [vital.key]: parseFloat(e.target.value)})}
                          className={`w-full bg-transparent border-none p-0 text-3xl font-black focus:ring-0 ${vital.critical ? 'text-danger' : 'text-slate-700 dark:text-slate-200'}`}
                        />
                        <span className={`text-xs font-bold ${vital.critical ? 'text-danger/70' : 'text-slate-400'}`}>{vital.unit}</span>
                      </div>
                      {vital.critical && <div className="mt-3 text-[10px] font-black text-white bg-danger px-2 py-1 rounded-lg inline-block shadow-sm">CRITICAL</div>}
                    </div>
                  ))}
                </div>
              </section>

              {/* Symptoms */}
              <section>
                <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-6 pl-1">
                  <span className="material-symbols-outlined text-lg">stethoscope</span> Primary Complaints
                </h3>
                <div className="flex flex-wrap gap-4">
                  {['Chest Pain', 'Shortness of Breath', 'Fever > 38°C', 'Nausea', 'Dizziness', 'Abdominal Pain'].map(sym => (
                    <button 
                      key={sym}
                      type="button"
                      onClick={() => handleSymptomToggle(sym)}
                      className={`group select-none rounded-[50px] px-6 py-3 text-sm font-bold transition-all border border-transparent ${
                        symptoms.includes(sym) 
                          ? 'bg-[#eef2f6] dark:bg-[#1e293b] text-primary dark:text-blue-400 shadow-[inset_4px_4px_8px_#d1d9e6,inset_-4px_-4px_8px_#ffffff] dark:shadow-[inset_4px_4px_8px_#0f1521,inset_-4px_-4px_8px_#2d3d55] translate-y-[1px]' 
                          : 'bg-[#eef2f6] dark:bg-[#1e293b] text-slate-600 dark:text-slate-300 shadow-[5px_5px_10px_#d1d9e6,-5px_-5px_10px_#ffffff] dark:shadow-[5px_5px_10px_#0b1120,-5px_-5px_10px_#31415e] hover:-translate-y-[2px]'
                      }`}
                    >
                      {sym}
                    </button>
                  ))}
                </div>
              </section>

              {/* Action Buttons */}
              <div className="pt-8 border-t border-slate-200 dark:border-slate-700/50 flex flex-col md:flex-row justify-between items-center gap-6">
                <div className="flex items-center gap-2 text-slate-400 dark:text-slate-500 animate-pulse">
                  <span className="material-symbols-outlined text-xl">save</span>
                  <span className="text-xs font-bold uppercase tracking-wider">Draft Auto-Saved</span>
                </div>
                <div className="flex gap-4 w-full md:w-auto">
                  <button className="flex-1 md:flex-none px-8 py-4 rounded-xl font-bold text-slate-500 hover:text-slate-700 transition-colors" type="button">Cancel</button>
                  <button 
                    onClick={handleGenerateDiagnosis}
                    disabled={loading}
                    className="flex-1 md:flex-none bg-gradient-to-br from-primary to-primary-dark text-white px-10 py-4 rounded-xl font-bold shadow-clay-primary hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 active:shadow-inner transition-all flex justify-center items-center gap-3 group"
                    type="button"
                  >
                    {loading ? (
                       <>
                         <span className="material-symbols-outlined animate-spin">progress_activity</span>
                         <span>Analyzing...</span>
                       </>
                    ) : (
                      <>
                        <span>Generate AI Diagnosis</span>
                        <span className="material-symbols-outlined group-hover:rotate-12 transition-transform">auto_awesome</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>

      {/* Right: Insights Panel */}
      <aside className="w-full lg:w-96 bg-surface-light dark:bg-surface-dark rounded-clay shadow-clay dark:shadow-clay-dark border border-white/50 dark:border-slate-700 flex flex-col z-10 sticky lg:top-6 h-fit lg:h-[calc(100vh-140px)]">
        <div className="p-6 border-b border-slate-200 dark:border-slate-700/30 rounded-t-[24px] bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm">
          <h2 className="flex items-center gap-2 font-black text-lg text-slate-800 dark:text-slate-100">
            <span className="material-symbols-outlined text-primary text-3xl">psychology_alt</span>
            Medyphas AI Insights
          </h2>
          <p className="text-xs font-medium text-slate-500 mt-1 pl-10">Real-time predictive analysis.</p>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar rounded-b-[24px]">
          {!result && !loading && (
             <div className="text-center py-10 text-slate-400">
                <span className="material-symbols-outlined text-4xl mb-2">medical_services</span>
                <p className="text-sm font-medium">Enter patient data to generate insights.</p>
             </div>
          )}

          {loading && (
            <div className="space-y-4 animate-pulse">
               <div className="h-24 bg-slate-200 dark:bg-slate-700 rounded-2xl"></div>
               <div className="h-24 bg-slate-200 dark:bg-slate-700 rounded-2xl"></div>
               <div className="h-24 bg-slate-200 dark:bg-slate-700 rounded-2xl"></div>
            </div>
          )}

          {result && (
            <>
              {/* Risk Alert */}
              <div className={`rounded-2xl p-5 shadow-sm border animate-in slide-in-from-right-4 duration-500 ${
                  result.riskLevel === RiskLevel.CRITICAL || result.riskLevel === RiskLevel.HIGH
                  ? 'bg-red-50 dark:bg-red-900/10 border-red-100 dark:border-red-900/30'
                  : 'bg-amber-50 dark:bg-amber-900/10 border-amber-100 dark:border-amber-900/30'
              }`}>
                <div className="flex items-start gap-4">
                  <div className={`p-3 rounded-xl shadow-sm ${
                     result.riskLevel === RiskLevel.CRITICAL || result.riskLevel === RiskLevel.HIGH 
                     ? 'bg-red-100 dark:bg-red-900/30 text-danger' 
                     : 'bg-amber-100 dark:bg-amber-900/30 text-amber-500'
                  }`}>
                    <span className="material-symbols-outlined text-2xl">priority_high</span>
                  </div>
                  <div>
                    <h4 className={`font-bold text-sm mb-1 ${
                       result.riskLevel === RiskLevel.CRITICAL || result.riskLevel === RiskLevel.HIGH 
                       ? 'text-danger' 
                       : 'text-amber-600'
                    }`}>{result.riskLevel} RISK DETECTED</h4>
                    <p className="text-xs font-medium text-slate-600 dark:text-slate-300 leading-relaxed">
                      {result.diagnosis}
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="bg-blue-50 dark:bg-blue-900/10 rounded-2xl p-5 shadow-sm border border-blue-100 dark:border-blue-900/30 animate-in slide-in-from-right-4 duration-500 delay-100">
                <div className="flex items-start gap-4">
                  <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-xl text-primary shadow-sm">
                    <span className="material-symbols-outlined text-2xl">fact_check</span>
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-primary mb-1">Recommended Actions</h4>
                    <ul className="text-xs font-medium text-slate-600 dark:text-slate-300 space-y-2">
                      {result.recommendedActions?.map((action: string, i: number) => (
                         <li key={i} className="flex items-start gap-2">
                           <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0"></span>
                           {action}
                         </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Confidence Footer */}
        {result && (
           <div className="p-6 border-t border-slate-200 dark:border-slate-700/30 bg-white/30 dark:bg-slate-800/30 rounded-b-[24px]">
            <div className="flex items-center justify-between text-xs font-bold text-slate-500 mb-3">
              <span className="uppercase tracking-wider">AI Confidence Score</span>
              <span className="text-primary text-base">{result.aiConfidence}%</span>
            </div>
            <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-3 shadow-inner">
              <div 
                className="bg-gradient-to-r from-blue-400 to-primary h-3 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)] transition-all duration-1000" 
                style={{ width: `${result.aiConfidence}%` }}
              ></div>
            </div>
          </div>
        )}
      </aside>
    </div>
  );
};